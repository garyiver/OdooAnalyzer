# odoo_analyzer/config.py

# Default value, will be updated by main script
BASE_DIR = ""